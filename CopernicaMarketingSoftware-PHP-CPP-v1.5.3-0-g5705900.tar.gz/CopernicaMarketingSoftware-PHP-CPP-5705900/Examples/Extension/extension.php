<?php
/*
 *  extension.php
 *  @author Jasper van Eck<jasper.vaneck@copernica.com>
 * 
 *  An example file to show the working of an extension.
 */

// print all the extensions currently loaded.
print_r(get_loaded_extensions());
